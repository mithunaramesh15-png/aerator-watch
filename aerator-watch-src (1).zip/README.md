# Aerator Watch

An Android app that watches two aerator splashes in the EseeCloud camera live view and rings a loud alarm when one of them stops.

**Download the app:** open the **Releases** section of this page and download `AeratorWatch.apk`.

## How it works
1. The app records the phone screen (only to analyse it, nothing is saved or sent anywhere).
2. Two boxes, *Aerator 1* and *Aerator 2*, are placed over the white splashes.
3. Every second it checks how much the picture inside each box changes.
4. If a splash stops moving for the chosen time (default 45 s), the alarm rings at full alarm volume and the phone vibrates.
5. The alarm also rings if the video freezes or screen recording stops.
