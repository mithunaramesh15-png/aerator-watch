package com.mithu.aeratorwatch;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** One watched area on the screen: an aerator splash or the camera clock. */
public class Box {
    public static final int AERATOR = 0, CLOCK = 1;

    public String name;
    public int type;
    public int x = -1, y = -1, w = -1, h = -1; // -1 = not placed yet
    public int sens = 3; // 1 (low) .. 5 (high)

    public Box(String name, int type) {
        this.name = name;
        this.type = type;
    }

    // Sensitivity tables: higher sensitivity = smaller pixel change counts, lower threshold.
    static float factor(int s) {
        return new float[]{0.5f, 0.4f, 0.3f, 0.2f, 0.12f}[clampS(s) - 1];
    }

    static float floor(int s) {
        return new float[]{1.0f, 0.7f, 0.5f, 0.35f, 0.25f}[clampS(s) - 1];
    }

    static int pixelDiff(int s) {
        return new int[]{20, 17, 14, 11, 9}[clampS(s) - 1];
    }

    static int clampS(int s) {
        return Math.max(1, Math.min(5, s));
    }

    static String sensName(int s) {
        return new String[]{"Low", "Medium-low", "Medium", "High", "Very high"}[clampS(s) - 1];
    }

    static List<Box> load(Context c) {
        SharedPreferences p = c.getSharedPreferences(WatchService.PREFS, Context.MODE_PRIVATE);
        List<Box> list = new ArrayList<>();
        String json = p.getString("boxes", null);
        if (json != null) {
            try {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    Box b = new Box(o.optString("name", "Box " + (i + 1)), o.optInt("type", AERATOR));
                    b.x = o.optInt("x", -1);
                    b.y = o.optInt("y", -1);
                    b.w = o.optInt("w", -1);
                    b.h = o.optInt("h", -1);
                    b.sens = o.optInt("sens", 3);
                    list.add(b);
                }
                return list;
            } catch (Exception ignored) {
                list.clear();
            }
        }
        // First run: two aerators and the camera clock.
        Box a1 = new Box("Aerator 1", AERATOR);
        a1.sens = 4; // the far aerator in the top view
        list.add(a1);
        list.add(new Box("Aerator 2", AERATOR));
        list.add(new Box("Clock", CLOCK));
        return list;
    }

    static void save(Context c, List<Box> list) {
        try {
            JSONArray a = new JSONArray();
            for (Box b : list) {
                JSONObject o = new JSONObject();
                o.put("name", b.name);
                o.put("type", b.type);
                o.put("x", b.x);
                o.put("y", b.y);
                o.put("w", b.w);
                o.put("h", b.h);
                o.put("sens", b.sens);
                a.put(o);
            }
            c.getSharedPreferences(WatchService.PREFS, Context.MODE_PRIVATE)
                    .edit().putString("boxes", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
