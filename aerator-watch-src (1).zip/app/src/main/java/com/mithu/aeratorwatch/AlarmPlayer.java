package com.mithu.aeratorwatch;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Plays a loud looping alarm on the ALARM volume and vibrates. */
public class AlarmPlayer {
    private final Context ctx;
    private MediaPlayer player;
    private ToneGenerator tone;
    private boolean playing = false;

    public AlarmPlayer(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public boolean isPlaying() {
        return playing;
    }

    public synchronized void start() {
        if (playing) return;
        playing = true;
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        try {
            am.setStreamVolume(AudioManager.STREAM_ALARM,
                    am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        } catch (Exception ignored) {
        }
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setDataSource(ctx, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            if (player != null) {
                try { player.release(); } catch (Exception ignored) { }
                player = null;
            }
            try {
                tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
                tone.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 10 * 60 * 1000);
            } catch (Exception ignored) {
            }
        }
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 900, 500}, 0));
        } catch (Exception ignored) {
        }
    }

    public synchronized void stop() {
        playing = false;
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        if (tone != null) {
            try { tone.stopTone(); tone.release(); } catch (Exception ignored) { }
            tone = null;
        }
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.cancel();
        } catch (Exception ignored) {
        }
    }
}
