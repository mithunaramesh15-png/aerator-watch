package com.mithu.aeratorwatch;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 100;

    private static final int BG = Color.rgb(16, 20, 26);
    private static final int CARD = Color.rgb(30, 37, 46);
    private static final int TEXT = Color.rgb(230, 236, 242);
    private static final int MUTED = Color.rgb(150, 162, 175);
    private static final int GREEN = Color.rgb(0, 150, 80);
    private static final int RED = Color.rgb(190, 40, 45);
    private static final int ACCENT = Color.rgb(0, 190, 230);
    private static final int CLOCK_C = Color.rgb(190, 120, 255);
    private static final int BTN = Color.rgb(48, 58, 72);

    private SharedPreferences prefs;
    private AlarmPlayer testAlarm;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView statusText, secondsText, logText;
    private Button mainBtn;
    private TextView perm1, perm2, perm3;
    private LinearLayout boxList;
    private List<Box> boxes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(WatchService.PREFS, MODE_PRIVATE);
        testAlarm = new AlarmPlayer(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        int pad = dp(16);
        root.setPadding(pad, dp(28), pad, dp(40));

        // ---------- header ----------
        TextView title = new TextView(this);
        title.setText("Aerator Watch");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(TEXT);
        root.addView(title);
        statusText = label("", 15, MUTED);
        root.addView(statusText);

        mainBtn = new Button(this);
        mainBtn.setTextSize(20);
        mainBtn.setAllCaps(false);
        mainBtn.setTextColor(Color.WHITE);
        mainBtn.setOnClickListener(v -> {
            if (WatchService.running) {
                startService(new Intent(this, WatchService.class).setAction(WatchService.ACTION_EXIT));
                handler.postDelayed(this::refreshAll, 400);
            } else {
                askToCapture();
            }
        });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        mlp.topMargin = dp(12);
        mlp.bottomMargin = dp(6);
        root.addView(mainBtn, mlp);

        // ---------- boxes ----------
        LinearLayout boxCard = card(root, "What to watch");
        boxCard.addView(label("Each box sits on one splash. The ⏱ Clock box sits on the camera's time "
                + "and tells \"video paused\" apart from \"aerator stopped\". Positions are set on the live view.", 13, MUTED));
        boxList = new LinearLayout(this);
        boxList.setOrientation(LinearLayout.VERTICAL);
        boxCard.addView(boxList);
        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);
        Button addA = flatButton("+ Aerator box", BTN);
        Button addC = flatButton("+ Clock box", BTN);
        addRow.addView(addA, weight(1));
        addRow.addView(addC, weight(1));
        boxCard.addView(addRow);
        addA.setOnClickListener(v -> {
            if (lockedWhileRunning()) return;
            int n = 1;
            for (Box b : boxes) if (b.type == Box.AERATOR) n++;
            boxes.add(new Box("Aerator " + n, Box.AERATOR));
            Box.save(this, boxes);
            buildBoxList();
        });
        addC.setOnClickListener(v -> {
            if (lockedWhileRunning()) return;
            for (Box b : boxes) {
                if (b.type == Box.CLOCK) {
                    Toast.makeText(this, "You already have a clock box", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            boxes.add(new Box("Clock", Box.CLOCK));
            Box.save(this, boxes);
            buildBoxList();
        });

        // ---------- alarm ----------
        LinearLayout alarmCard = card(root, "Alarm");
        alarmCard.addView(label("Ring when a splash is missing for:", 14, TEXT));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = flatButton("−", BTN);
        Button plus = flatButton("+", BTN);
        minus.setTextSize(22);
        plus.setTextSize(22);
        secondsText = label("", 20, TEXT);
        secondsText.setGravity(Gravity.CENTER);
        row.addView(minus, new LinearLayout.LayoutParams(dp(64), dp(52)));
        row.addView(secondsText, weight(1));
        row.addView(plus, new LinearLayout.LayoutParams(dp(64), dp(52)));
        alarmCard.addView(row);
        minus.setOnClickListener(v -> changeSeconds(-15));
        plus.setOnClickListener(v -> changeSeconds(15));
        alarmCard.addView(label("Longer = fewer false alarms from slow internet. 60–120 s works well.", 12, MUTED));

        Switch auto = new Switch(this);
        auto.setText("Stop the alarm by itself when everything runs again");
        auto.setTextColor(TEXT);
        auto.setTextSize(14);
        auto.setPadding(0, dp(10), 0, dp(6));
        auto.setChecked(prefs.getBoolean("autostop", false));
        auto.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("autostop", on).apply());
        alarmCard.addView(auto);

        Button test = flatButton("🔊  Test alarm (5 seconds)", BTN);
        test.setOnClickListener(v -> {
            testAlarm.start();
            handler.postDelayed(testAlarm::stop, 5000);
        });
        alarmCard.addView(test);

        // ---------- history ----------
        LinearLayout logCard = card(root, "History");
        logText = label("", 13, TEXT);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setTextIsSelectable(true);
        logCard.addView(logText);
        LinearLayout logRow = new LinearLayout(this);
        logRow.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = flatButton("Refresh", BTN);
        Button clear = flatButton("Clear history", BTN);
        logRow.addView(refresh, weight(1));
        logRow.addView(clear, weight(1));
        logCard.addView(logRow);
        refresh.setOnClickListener(v -> refreshLog());
        clear.setOnClickListener(v -> {
            EventLog.clear(this);
            refreshLog();
        });

        // ---------- one-time setup ----------
        LinearLayout setup = card(root, "One-time setup");
        perm1 = permRow(setup, "Display over other apps", v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        setup.addView(label("If Android says \"App was denied access\": Settings → Apps → Aerator Watch → ⋮ (top right) "
                + "→ Allow restricted settings. Then try again.", 12, MUTED));
        perm2 = permRow(setup, "Notifications", v -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        });
        perm3 = permRow(setup, "Run all night (battery)", v -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });

        // ---------- tips ----------
        LinearLayout tips = card(root, "Tips for a good night");
        tips.addView(label("• Keep the phone plugged in, upright, on a hard surface. Brightness can be at minimum.\n"
                + "• Choose \"Entire screen\" when Android asks.\n"
                + "• Keep EseeCloud live view open in SD. Do not lock the phone.\n"
                + "• Zoom the far camera view in EseeCloud so the splash looks bigger, and keep each box tight around its splash.\n"
                + "• Do not let the floating panel cover a box. Drag it away or tap — to shrink it.\n"
                + "• Watch the first 10–15 minutes to check there are no false alarms.", 13, TEXT));

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAll();
    }

    private void refreshAll() {
        boolean run = WatchService.running;
        statusText.setText(run ? "● Watching now. Use the floating panel on the live view."
                : "○ Not watching");
        statusText.setTextColor(run ? Color.rgb(40, 210, 90) : MUTED);
        mainBtn.setText(run ? "■  STOP WATCHING" : "▶  START WATCHING");
        mainBtn.setBackground(round(run ? RED : GREEN, 14));

        boolean overlay = Settings.canDrawOverlays(this);
        boolean notif = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        boolean batt = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        setPerm(perm1, overlay);
        setPerm(perm2, notif);
        setPerm(perm3, batt);

        changeSeconds(0);
        boxes = Box.load(this);
        buildBoxList();
        refreshLog();
    }

    private void refreshLog() {
        String log = EventLog.get(this);
        logText.setText(log.isEmpty() ? "Nothing yet. Stops, restarts and alarms will appear here." : log);
    }

    // ---------- box list ----------

    private boolean lockedWhileRunning() {
        if (WatchService.running) {
            Toast.makeText(this, "Stop watching first to change boxes here. "
                    + "(You can still move boxes on the live view with EDIT.)", Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }

    private void buildBoxList() {
        boxList.removeAllViews();
        boolean run = WatchService.running;
        for (int i = 0; i < boxes.size(); i++) {
            final Box b = boxes.get(i);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(12), dp(8), dp(12), dp(10));
            item.setBackground(round(Color.rgb(40, 48, 60), 12));
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            ilp.topMargin = dp(8);

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView icon = label(b.type == Box.CLOCK ? "⏱" : "●", 18, b.type == Box.CLOCK ? CLOCK_C : ACCENT);
            EditText name = new EditText(this);
            name.setText(b.name);
            name.setTextColor(TEXT);
            name.setTextSize(16);
            name.setSingleLine(true);
            name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
            name.setEnabled(!run);
            name.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
                public void onTextChanged(CharSequence s, int a, int c, int d) { }
                public void afterTextChanged(Editable s) {
                    String t = s.toString().trim();
                    b.name = t.isEmpty() ? "Box" : t;
                    Box.save(MainActivity.this, boxes);
                }
            });
            Button del = flatButton("Delete", Color.rgb(90, 40, 45));
            del.setTextSize(13);
            del.setOnClickListener(v -> {
                if (lockedWhileRunning()) return;
                boxes.remove(b);
                Box.save(this, boxes);
                buildBoxList();
            });
            top.addView(icon);
            LinearLayout.LayoutParams nlp = weight(1);
            nlp.leftMargin = dp(6);
            top.addView(name, nlp);
            top.addView(del, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42)));
            item.addView(top);

            final TextView sensLabel = label("", 13, MUTED);
            item.addView(sensLabel);
            SeekBar sb = new SeekBar(this);
            sb.setMax(4);
            sb.setProgress(Box.clampS(b.sens) - 1);
            sb.setEnabled(!run);
            sensLabel.setText(sensText(b));
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean user) {
                    b.sens = p + 1;
                    sensLabel.setText(sensText(b));
                    if (user) Box.save(MainActivity.this, boxes);
                }
                public void onStartTrackingTouch(SeekBar s) { }
                public void onStopTrackingTouch(SeekBar s) { }
            });
            item.addView(sb);
            boxList.addView(item, ilp);
        }
        if (boxes.isEmpty()) boxList.addView(label("No boxes. Add one below.", 14, MUTED));
        if (run) boxList.addView(label("Stop watching to rename, delete or change sensitivity.", 12, MUTED));
    }

    private String sensText(Box b) {
        String extra = b.type == Box.CLOCK ? "" :
                (b.sens >= 4 ? "  (good for a far / small splash)" : b.sens <= 2 ? "  (fewer false alarms)" : "");
        return "Sensitivity: " + Box.sensName(b.sens) + extra;
    }

    // ---------- settings ----------

    private void changeSeconds(int delta) {
        int s = prefs.getInt("still", 90) + delta;
        s = Math.max(15, Math.min(600, s));
        prefs.edit().putInt("still", s).apply();
        secondsText.setText(s + " seconds");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshAll();
    }

    private void askToCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "First allow \"Display over other apps\" (One-time setup below)", Toast.LENGTH_LONG).show();
            return;
        }
        if (boxes == null || boxes.isEmpty()) {
            Toast.makeText(this, "Add at least one box first", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent i;
        if (Build.VERSION.SDK_INT >= 34) {
            i = mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            i = mpm.createScreenCaptureIntent();
        }
        startActivityForResult(i, REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Screen permission was not given", Toast.LENGTH_LONG).show();
            return;
        }
        Intent s = new Intent(this, WatchService.class)
                .setAction(WatchService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data);
        startForegroundService(s);
        Toast.makeText(this, "Now open the EseeCloud live view and place the boxes", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    // ---------- small UI helpers ----------

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(14));
        c.setBackground(round(CARD, 16));
        TextView h = label(heading, 17, TEXT);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        c.addView(h);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        parent.addView(c, lp);
        return c;
    }

    private TextView permRow(LinearLayout parent, String text, View.OnClickListener click) {
        TextView t = label(text, 15, TEXT);
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setBackground(round(Color.rgb(40, 48, 60), 12));
        t.setOnClickListener(click);
        t.setTag(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        parent.addView(t, lp);
        return t;
    }

    private void setPerm(TextView t, boolean ok) {
        t.setText((ok ? "✅  " : "⚠️  ") + t.getTag() + (ok ? "" : "   (tap to allow)"));
    }

    private TextView label(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private Button flatButton(String s, int bg) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setBackground(round(bg, 12));
        return b;
    }

    private LinearLayout.LayoutParams weight(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w);
        lp.setMargins(dp(3), dp(6), dp(3), dp(3));
        return lp;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
