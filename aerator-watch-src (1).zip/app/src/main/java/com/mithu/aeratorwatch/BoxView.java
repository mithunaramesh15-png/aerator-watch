package com.mithu.aeratorwatch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * A see-through rectangle drawn over the camera video.
 * Only static things are drawn inside it while watching (border + name),
 * so the box itself never looks like "movement".
 */
public class BoxView extends View {
    private String label;
    private final boolean clock;
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint xPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private boolean editable = true;
    private int color = Color.CYAN;

    public BoxView(Context c, String label, boolean clock) {
        super(c);
        this.label = label;
        this.clock = clock;
        dp = c.getResources().getDisplayMetrics().density;
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(3 * dp);
        fill.setStyle(Paint.Style.FILL);
        text.setColor(Color.WHITE);
        text.setTextSize(11 * dp);
        text.setFakeBoldText(true);
        text.setShadowLayer(3 * dp, 0, 0, Color.BLACK);
        xPaint.setColor(Color.WHITE);
        xPaint.setStrokeWidth(2.2f * dp);
        xPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setLabel(String l) {
        label = l;
        invalidate();
    }

    /** Only redraws when something actually changed. */
    public void setState(int color, boolean editable) {
        if (this.color == color && this.editable == editable) return;
        this.color = color;
        this.editable = editable;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float s = border.getStrokeWidth() / 2f;
        border.setColor(color);
        fill.setColor(color);
        c.drawRect(s, s, w - s, h - s, border);
        if (!clock || editable) {
            c.drawText(clock ? "⏱" : label, 6 * dp, 14 * dp, text);
        }
        if (editable) {
            // resize handle (bottom-right)
            float k = 22 * dp;
            Path p = new Path();
            p.moveTo(w, h - k);
            p.lineTo(w, h);
            p.lineTo(w - k, h);
            p.close();
            c.drawPath(p, fill);
            // delete "x" (top-right)
            float r = 9 * dp, cx = w - r - 3 * dp, cy = r + 3 * dp;
            fill.setColor(Color.rgb(200, 40, 40));
            c.drawCircle(cx, cy, r, fill);
            float d = r * 0.45f;
            c.drawLine(cx - d, cy - d, cx + d, cy + d, xPaint);
            c.drawLine(cx - d, cy + d, cx + d, cy - d, xPaint);
        }
    }
}
