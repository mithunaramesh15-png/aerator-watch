package com.mithu.aeratorwatch;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Watches boxes on the screen (the EseeCloud live view).
 * Aerator boxes: alarm when the splash stops moving.
 * Clock box: tells "video paused" apart from "aerator stopped".
 */
public class WatchService extends Service {
    static final String ACTION_START = "com.mithu.aeratorwatch.START";
    static final String ACTION_STOP_ALARM = "com.mithu.aeratorwatch.STOP_ALARM";
    static final String ACTION_EXIT = "com.mithu.aeratorwatch.EXIT";
    static final String PREFS = "aerator";
    static volatile boolean running = false;

    private static final int NOTIF_ID = 1;
    private static final int ALARM_NOTIF_ID = 2;
    private static final int CALIB_TICKS = 15;
    private static final int CLOCK_MAX_WINDOW = 30;
    private static final int RESUME_TICKS = 5;

    private static final int SETUP = 0, CALIB = 1, WATCH = 2, ALARM = 3, ENDED = 4;

    private static final int C_SETUP = Color.rgb(0, 200, 255);
    private static final int C_CLOCK = Color.rgb(200, 120, 255);
    private static final int C_OK = Color.rgb(40, 210, 90);
    private static final int C_WARN = Color.rgb(255, 170, 0);
    private static final int C_BAD = Color.rgb(255, 60, 60);
    private static final int C_LEARN = Color.rgb(255, 230, 0);
    private static final int PANEL_BG = 0xE6161B22;
    private static final int PANEL_ALARM = 0xEEB00020;

    /** Everything the service knows about one box. */
    private class Slot {
        Box box;
        BoxView view;
        WindowManager.LayoutParams lp;
        TextView row;
        int[] prev;
        float thr;
        float[] calib = new float[CALIB_TICKS];
        int calibN;
        boolean[] hist;
        int histPos, histCount;
        int stillRun, moveRun;
        boolean stopped;
        long stoppedAt;
        float score;

        boolean isClock() {
            return box.type == Box.CLOCK;
        }
    }

    private WindowManager wm;
    private Context ui;
    private Handler handler;
    private SharedPreferences prefs;
    private AlarmPlayer alarm;
    private PowerManager.WakeLock wakeLock;

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;
    private int screenW, screenH, capW, capH;

    private final List<Slot> slots = new ArrayList<>();
    private LinearLayout panel, panelBody, rowsBox;
    private WindowManager.LayoutParams panelLp;
    private TextView dot, title, message;
    private Button startBtn, addBtn;
    private boolean minimized = false;

    private int state = SETUP;
    private boolean cleaned = false;
    private int calibTick = 0;
    private int stillSeconds = 90;
    private boolean autoStop = false;
    private long snoozeUntil = 0;
    private int allGoodTicks = 0;
    private String alarmReason = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        ui = new ContextThemeWrapper(this, android.R.style.Theme_Material);
        handler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        alarm = new AlarmPlayer(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("watch", "Watching", NotificationManager.IMPORTANCE_LOW));
        NotificationChannel ch = new NotificationChannel("alarm", "Aerator alarm", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String a = intent.getAction();
        if (ACTION_START.equals(a)) {
            if (projection != null) return START_NOT_STICKY;
            Notification n = buildNotification("Place the boxes, then press START.");
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIF_ID, n);
            }
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            try {
                projection = mpm.getMediaProjection(code, data);
            } catch (Exception e) {
                projection = null;
            }
            if (projection == null) {
                cleanup();
                return START_NOT_STICKY;
            }
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    handler.post(WatchService.this::onProjectionStopped);
                }
            }, handler);
            setupCapture();
            showOverlays();
            acquireWakeLock();
            running = true;
            handler.post(tick);
        } else if (ACTION_STOP_ALARM.equals(a)) {
            stopAlarm(true);
        } else if (ACTION_EXIT.equals(a)) {
            cleanup();
        }
        return START_NOT_STICKY;
    }

    // ================= screen capture =================

    private void setupCapture() {
        if (Build.VERSION.SDK_INT >= 30) {
            screenW = wm.getMaximumWindowMetrics().getBounds().width();
            screenH = wm.getMaximumWindowMetrics().getBounds().height();
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        }
        capW = Math.max(2, (screenW / 2) & ~1);
        capH = Math.max(2, (screenH / 2) & ~1);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        vdisplay = projection.createVirtualDisplay("aerator-watch", capW, capH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
    }

    // ================= overlays =================

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private WindowManager.LayoutParams overlayParams(int w, int h, int extraFlags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | extraFlags,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        p.gravity = Gravity.TOP | Gravity.LEFT;
        return p;
    }

    private void placeDefault(Box b, int index) {
        if (b.type == Box.CLOCK) {
            if (b.w <= 0) b.w = (int) (screenW * 0.38f);
            if (b.h <= 0) b.h = dp(28);
            if (b.x < 0) b.x = dp(4);
            if (b.y < 0) b.y = (int) (screenH * 0.12f);
        } else {
            if (b.w <= 0) b.w = (int) (screenW * 0.35f);
            if (b.h <= 0) b.h = (int) (screenH * 0.09f);
            if (b.x < 0) b.x = (int) (screenW * 0.30f);
            if (b.y < 0) b.y = (int) (screenH * (0.22f + 0.14f * (index % 4)));
        }
    }

    private void showOverlays() {
        List<Box> boxes = Box.load(this);
        for (int i = 0; i < boxes.size(); i++) addSlot(boxes.get(i), i);
        buildPanel();
        refreshRows();
        setMessage("Open EseeCloud live view. Drag each box onto its splash, and the ⏱ box onto the camera clock. "
                + "Corner = resize, red ✕ = delete. Then press START.");
    }

    private void addSlot(Box b, int index) {
        placeDefault(b, index);
        Slot s = new Slot();
        s.box = b;
        s.view = new BoxView(this, b.name, b.type == Box.CLOCK);
        s.lp = overlayParams(b.w, b.h, 0);
        s.lp.x = b.x;
        s.lp.y = b.y;
        s.view.setOnTouchListener(new BoxTouch(s));
        s.view.setState(b.type == Box.CLOCK ? C_CLOCK : C_SETUP, true);
        try {
            wm.addView(s.view, s.lp);
        } catch (Exception ignored) {
        }
        slots.add(s);
        if (rowsBox != null) refreshRows();
    }

    private void removeSlot(Slot s) {
        try {
            wm.removeView(s.view);
        } catch (Exception ignored) {
        }
        slots.remove(s);
        saveBoxes();
        refreshRows();
    }

    private void saveBoxes() {
        List<Box> list = new ArrayList<>();
        for (Slot s : slots) list.add(s.box);
        Box.save(this, list);
    }

    private void buildPanel() {
        panel = new LinearLayout(ui);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(10);
        panel.setPadding(pad, dp(6), pad, pad);
        setPanelColor(PANEL_BG);

        // Header: dot + title + minimise button. Drag the header to move the panel.
        LinearLayout header = new LinearLayout(ui);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        dot = new TextView(ui);
        dot.setText("●");
        dot.setTextSize(18);
        dot.setTextColor(C_SETUP);
        title = new TextView(ui);
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(6), 0, dp(6), 0);
        title.setText("Aerator Watch");
        TextView minBtn = new TextView(ui);
        minBtn.setText("—");
        minBtn.setTextColor(Color.WHITE);
        minBtn.setTextSize(18);
        minBtn.setPadding(dp(12), dp(4), dp(4), dp(4));
        header.addView(dot);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        header.addView(minBtn);
        panel.addView(header);

        panelBody = new LinearLayout(ui);
        panelBody.setOrientation(LinearLayout.VERTICAL);
        rowsBox = new LinearLayout(ui);
        rowsBox.setOrientation(LinearLayout.VERTICAL);
        rowsBox.setPadding(0, dp(4), 0, dp(4));
        panelBody.addView(rowsBox);
        message = new TextView(ui);
        message.setTextColor(0xFFCCD3DB);
        message.setTextSize(12);
        message.setPadding(0, 0, 0, dp(6));
        panelBody.addView(message);

        LinearLayout row = new LinearLayout(ui);
        row.setOrientation(LinearLayout.HORIZONTAL);
        startBtn = smallButton("START", Color.rgb(0, 140, 70));
        addBtn = smallButton("+ BOX", Color.rgb(50, 60, 75));
        Button stopBtn = smallButton("STOP ALARM", Color.rgb(170, 30, 30));
        Button exitBtn = smallButton("EXIT", Color.rgb(50, 60, 75));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, dp(40), 1);
        bl.setMargins(dp(2), 0, dp(2), 0);
        row.addView(startBtn, bl);
        row.addView(addBtn, new LinearLayout.LayoutParams(bl));
        LinearLayout.LayoutParams wide = new LinearLayout.LayoutParams(0, dp(40), 1.4f);
        wide.setMargins(dp(2), 0, dp(2), 0);
        row.addView(stopBtn, wide);
        row.addView(exitBtn, new LinearLayout.LayoutParams(bl));
        panelBody.addView(row);
        panel.addView(panelBody);

        startBtn.setOnClickListener(v -> {
            if (state == SETUP) beginWatching();
            else backToSetup();
        });
        addBtn.setOnClickListener(v -> {
            int n = 1;
            for (Slot s : slots) if (!s.isClock()) n++;
            Box b = new Box("Aerator " + n, Box.AERATOR);
            b.x = (int) (screenW * 0.30f);
            b.y = (int) (screenH * 0.35f);
            addSlot(b, slots.size());
            saveBoxes();
        });
        stopBtn.setOnClickListener(v -> stopAlarm(true));
        exitBtn.setOnClickListener(v -> cleanup());
        minBtn.setOnClickListener(v -> setMinimized(!minimized));

        View.OnTouchListener drag = new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX();
                        dy = e.getRawY();
                        sx = panelLp.x;
                        sy = panelLp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int mx = (int) (e.getRawX() - dx), my = (int) (e.getRawY() - dy);
                        if (Math.abs(mx) > dp(6) || Math.abs(my) > dp(6)) moved = true;
                        panelLp.x = Math.max(0, sx + mx);
                        panelLp.y = Math.max(0, sy + my);
                        safeUpdate(panel, panelLp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) setMinimized(!minimized);
                        prefs.edit().putInt("px", panelLp.x).putInt("py", panelLp.y).apply();
                        return true;
                }
                return false;
            }
        };
        header.setOnTouchListener(drag);
        title.setOnTouchListener(drag);
        dot.setOnTouchListener(drag);

        panelLp = overlayParams((int) Math.min(screenW * 0.94f, dp(440)),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        panelLp.x = prefs.getInt("px", (int) (screenW * 0.03f));
        panelLp.y = prefs.getInt("py", (int) (screenH * 0.66f));
        wm.addView(panel, panelLp);
    }

    private Button smallButton(String t, int bg) {
        Button b = new Button(ui);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        return b;
    }

    private void setMinimized(boolean m) {
        minimized = m;
        panelBody.setVisibility(m ? View.GONE : View.VISIBLE);
        panelLp.width = m ? WindowManager.LayoutParams.WRAP_CONTENT : (int) Math.min(screenW * 0.94f, dp(440));
        safeUpdate(panel, panelLp);
        updateTitle();
    }

    private void setPanelColor(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(16));
        panel.setBackground(bg);
    }

    private void setMessage(String s) {
        if (message != null && !s.contentEquals(message.getText())) message.setText(s);
    }

    private void refreshRows() {
        if (rowsBox == null) return;
        rowsBox.removeAllViews();
        for (Slot s : slots) {
            s.row = new TextView(ui);
            s.row.setTextSize(13);
            s.row.setTextColor(Color.WHITE);
            s.row.setPadding(0, dp(1), 0, dp(1));
            rowsBox.addView(s.row);
        }
        updateRows();
    }

    private void safeUpdate(View v, WindowManager.LayoutParams p) {
        try {
            wm.updateViewLayout(v, p);
        } catch (Exception ignored) {
        }
    }

    private class BoxTouch implements View.OnTouchListener {
        private final Slot s;
        private float downX, downY;
        private int sx, sy, sw, sh;
        private int mode; // 0 move, 1 resize, 2 delete
        private boolean moved;

        BoxTouch(Slot s) {
            this.s = s;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            if (state != SETUP) return false;
            WindowManager.LayoutParams p = s.lp;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    sx = p.x;
                    sy = p.y;
                    sw = v.getWidth();
                    sh = v.getHeight();
                    moved = false;
                    int corner = dp(40);
                    if (e.getX() > sw - dp(30) && e.getY() < dp(30)) mode = 2;
                    else if (e.getX() > sw - corner && e.getY() > sh - corner) mode = 1;
                    else mode = 0;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (e.getRawX() - downX), dy = (int) (e.getRawY() - downY);
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                    if (mode == 2 && moved) mode = 0;
                    if (mode == 1) {
                        p.width = Math.max(dp(40), sw + dx);
                        p.height = Math.max(dp(22), sh + dy);
                    } else if (mode == 0) {
                        p.x = sx + dx;
                        p.y = sy + dy;
                    }
                    safeUpdate(v, p);
                    s.prev = null;
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (mode == 2 && !moved) {
                        removeSlot(s);
                        return true;
                    }
                    s.box.x = p.x;
                    s.box.y = p.y;
                    s.box.w = v.getWidth();
                    s.box.h = v.getHeight();
                    saveBoxes();
                    return true;
            }
            return false;
        }
    }

    private void setBoxesEditable(boolean editable) {
        for (Slot s : slots) {
            if (editable) s.lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            else s.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            safeUpdate(s.view, s.lp);
            s.view.setState(s.isClock() ? C_CLOCK : C_SETUP, editable);
        }
    }

    // ================= watching logic =================

    private int windowFor(Slot s) {
        return s.isClock() ? Math.min(stillSeconds, CLOCK_MAX_WINDOW) : stillSeconds;
    }

    private void resetSlotHistory(Slot s) {
        s.hist = new boolean[windowFor(s)];
        s.histPos = 0;
        s.histCount = 0;
        s.stillRun = 0;
        s.moveRun = 0;
    }

    private void beginWatching() {
        if (slots.isEmpty()) {
            setMessage("Add at least one box first (+ BOX).");
            return;
        }
        stillSeconds = prefs.getInt("still", 90);
        autoStop = prefs.getBoolean("autostop", false);
        for (Slot s : slots) {
            resetSlotHistory(s);
            s.calibN = 0;
            s.stopped = false;
            s.prev = null;
        }
        calibTick = 0;
        snoozeUntil = 0;
        allGoodTicks = 0;
        state = CALIB;
        setBoxesEditable(false);
        startBtn.setText("EDIT");
        addBtn.setVisibility(View.GONE);
        int aer = 0, clk = 0;
        for (Slot s : slots) if (s.isClock()) clk++; else aer++;
        EventLog.add(this, "Watching started (" + aer + " aerator" + (aer == 1 ? "" : "s")
                + (clk > 0 ? " + clock" : "") + ", alarm after " + stillSeconds + " s)");
        updateNotification("Watching the aerators.");
    }

    private void backToSetup() {
        alarm.stop();
        cancelAlarmNotification();
        if (projection == null) return;
        if (state == WATCH || state == ALARM || state == CALIB) EventLog.add(this, "Watching paused to edit boxes");
        state = SETUP;
        setPanelColor(PANEL_BG);
        setBoxesEditable(true);
        startBtn.setText("START");
        addBtn.setVisibility(View.VISIBLE);
        setMessage("Edit the boxes, then press START.");
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (state == ENDED || cleaned) return;
            try {
                doTick();
            } catch (Exception ignored) {
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void doTick() {
        for (Slot s : slots) s.score = 0f;
        Image img = null;
        try {
            img = reader.acquireLatestImage();
        } catch (Exception ignored) {
        }
        if (img != null) {
            try {
                Image.Plane pl = img.getPlanes()[0];
                ByteBuffer buf = pl.getBuffer();
                for (Slot s : slots) s.score = measure(s, buf, pl.getPixelStride(), pl.getRowStride());
            } finally {
                img.close();
            }
        }
        // No new frame = nothing on screen changed = score 0 ("still").

        switch (state) {
            case CALIB:
                for (Slot s : slots) {
                    if (s.score > 0 && s.calibN < CALIB_TICKS) s.calib[s.calibN++] = s.score;
                    s.view.setState(C_LEARN, false);
                }
                calibTick++;
                setMessage("Learning what normal looks like... keep the aerators running ("
                        + (CALIB_TICKS - calibTick) + " s)");
                if (calibTick >= CALIB_TICKS) finishCalibration();
                break;
            case WATCH:
            case ALARM:
                watchStep();
                break;
        }
        updateRows();
        updateTitle();
    }

    private void finishCalibration() {
        StringBuilder warn = new StringBuilder();
        for (Slot s : slots) {
            float median = 0f;
            if (s.calibN > 0) {
                float[] v = Arrays.copyOf(s.calib, s.calibN);
                Arrays.sort(v);
                median = v[v.length / 2];
            }
            s.thr = Math.max(median * Box.factor(s.box.sens), Box.floor(s.box.sens));
            if (median < s.thr * 2f) {
                warn.append("\n⚠ ").append(s.box.name).append(": very little movement seen. ")
                        .append(s.isClock() ? "Put the box on the seconds of the clock."
                                : "Make the box smaller around the splash, zoom in, or raise its sensitivity.");
            }
            resetSlotHistory(s);
        }
        state = WATCH;
        setMessage("Watching. Alarm if a splash is missing for " + stillSeconds + " s." + warn);
    }

    /** Push one result into a box's history. Returns true if the box changed state. */
    private void updateSlot(Slot s, long now) {
        boolean moving = s.score < 0 || s.score >= s.thr;
        s.hist[s.histPos] = moving;
        s.histPos = (s.histPos + 1) % s.hist.length;
        if (s.histCount < s.hist.length) s.histCount++;
        s.stillRun = moving ? 0 : s.stillRun + 1;
        s.moveRun = moving ? s.moveRun + 1 : 0;
        int movingCount = 0;
        for (int i = 0; i < s.histCount; i++) if (s.hist[i]) movingCount++;
        int n = s.hist.length;
        if (!s.stopped && s.histCount >= n && movingCount <= n * 0.15f) {
            s.stopped = true;
            s.stoppedAt = now;
            EventLog.add(this, s.isClock() ? "VIDEO PAUSED (camera clock stopped)" : s.box.name + " STOPPED");
        } else if (s.stopped && s.moveRun >= RESUME_TICKS) {
            s.stopped = false;
            long mins = Math.max(1, Math.round((now - s.stoppedAt) / 60000.0));
            EventLog.add(this, (s.isClock() ? "Video running again" : s.box.name + " running again")
                    + " (off about " + mins + " min)");
            int keepMoveRun = s.moveRun;
            resetSlotHistory(s);
            s.moveRun = keepMoveRun;
        }
    }

    private void watchStep() {
        long now = System.currentTimeMillis();
        boolean paused = false;
        for (Slot s : slots) {
            if (!s.isClock()) continue;
            updateSlot(s, now);
            if (s.stopped) paused = true;
        }
        List<String> stoppedNames = new ArrayList<>();
        for (Slot s : slots) {
            if (s.isClock()) continue;
            // While the video is paused we cannot see the aerators: freeze their history.
            if (!paused) updateSlot(s, now);
            if (s.stopped) stoppedNames.add(s.box.name);
        }

        String reason = null;
        if (paused) reason = "VIDEO PAUSED: check internet / EseeCloud";
        else if (!stoppedNames.isEmpty()) reason = join(stoppedNames) + " STOPPED!";

        if (reason != null) {
            allGoodTicks = 0;
            alarmReason = reason;
            if (state != ALARM && now >= snoozeUntil) triggerAlarm(reason);
        } else {
            allGoodTicks++;
            if (state == ALARM && autoStop && allGoodTicks >= 10) {
                EventLog.add(this, "Alarm stopped automatically: everything running");
                stopAlarm(false);
            }
        }

        if (state == ALARM) {
            setMessage("⚠ " + alarmReason + "\nPress STOP ALARM.");
        } else if (reason != null) {
            long left = Math.max(0, (snoozeUntil - now) / 1000);
            setMessage("⚠ " + reason + "\nAlarm silenced. Rings again in " + left + " s if not fixed.");
        } else {
            setMessage("Watching. Alarm if a splash is missing for " + stillSeconds + " s.");
        }

        for (Slot s : slots) {
            int c;
            if (s.stopped) c = C_BAD;
            else if (!s.isClock() && paused) c = C_WARN;
            else if (s.stillRun > 3) c = C_WARN;
            else c = C_OK;
            s.view.setState(c, false);
        }
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(i == l.size() - 1 ? " & " : ", ");
            sb.append(l.get(i));
        }
        return sb.toString();
    }

    private void updateRows() {
        boolean paused = false;
        for (Slot s : slots) if (s.isClock() && s.stopped) paused = true;
        for (Slot s : slots) {
            if (s.row == null) continue;
            String st;
            int c;
            if (state == SETUP) {
                st = "movement " + fmt(s.score);
                c = s.isClock() ? C_CLOCK : C_SETUP;
            } else if (state == CALIB) {
                st = "learning... " + fmt(s.score);
                c = C_LEARN;
            } else if (s.stopped) {
                st = s.isClock() ? "PAUSED" : "STOPPED";
                c = C_BAD;
            } else if (!s.isClock() && paused) {
                st = "can't see (video paused)";
                c = C_WARN;
            } else if (s.stillRun > 3) {
                st = (s.isClock() ? "not ticking " : "still ") + s.stillRun + " s";
                c = C_WARN;
            } else {
                st = (s.isClock() ? "ticking " : "running ") + fmt(s.score);
                c = C_OK;
            }
            String txt = "●  " + (s.isClock() ? "⏱ " : "") + s.box.name + "   " + st;
            if (!txt.contentEquals(s.row.getText())) s.row.setText(txt);
            s.row.setTextColor(c);
        }
    }

    private void updateTitle() {
        if (dot == null) return;
        int c;
        String t;
        switch (state) {
            case SETUP:
                c = C_SETUP;
                t = "Setup: place boxes";
                break;
            case CALIB:
                c = C_LEARN;
                t = "Learning...";
                break;
            case ALARM:
                c = C_BAD;
                t = minimized ? "ALARM" : "ALARM!";
                break;
            case ENDED:
                c = Color.GRAY;
                t = "Stopped";
                break;
            default:
                boolean warn = false;
                for (Slot s : slots) if (s.stopped || s.stillRun > 3) warn = true;
                c = warn ? C_WARN : C_OK;
                t = warn ? "Watching (check)" : "Watching: all OK";
        }
        dot.setTextColor(c);
        String full = minimized ? t : "Aerator Watch  ·  " + t;
        if (!full.contentEquals(title.getText())) title.setText(full);
    }

    /** Percentage of sample points inside the box that changed since the last check. */
    private float measure(Slot s, ByteBuffer buf, int ps, int rs) {
        BoxView v = s.view;
        int w = v.getWidth(), h = v.getHeight();
        if (w == 0 || h == 0) return -1;
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        float sx = capW / (float) screenW, sy = capH / (float) screenH;
        int side = dp(5), top = s.isClock() ? dp(5) : dp(18);
        int x0 = clamp((int) ((loc[0] + side) * sx), 0, capW - 1);
        int x1 = clamp((int) ((loc[0] + w - side) * sx), 0, capW - 1);
        int y0 = clamp((int) ((loc[1] + top) * sy), 0, capH - 1);
        int y1 = clamp((int) ((loc[1] + h - side) * sy), 0, capH - 1);
        if (x1 - x0 < 3 || y1 - y0 < 2) return -1;
        int step = Math.max(1, Math.max(x1 - x0, y1 - y0) / 90);
        int nx = (x1 - x0) / step, ny = (y1 - y0) / step;
        int n = nx * ny;
        if (n <= 0) return -1;
        int[] cur = new int[n];
        int k = 0;
        int limit = buf.limit();
        for (int yy = 0; yy < ny; yy++) {
            int py = y0 + yy * step;
            for (int xx = 0; xx < nx; xx++) {
                int off = py * rs + (x0 + xx * step) * ps;
                if (off + 2 >= limit) {
                    cur[k++] = 0;
                    continue;
                }
                int r = buf.get(off) & 0xff, g = buf.get(off + 1) & 0xff, b = buf.get(off + 2) & 0xff;
                cur[k++] = (r + 2 * g + b) >> 2;
            }
        }
        int[] p = s.prev;
        s.prev = cur;
        if (p == null || p.length != n) return -1;
        int diff = Box.pixelDiff(s.box.sens);
        int changed = 0;
        for (int j = 0; j < n; j++) if (Math.abs(cur[j] - p[j]) > diff) changed++;
        return 100f * changed / n;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static String fmt(float s) {
        if (s < 0) return "...";
        return String.format(Locale.US, "%.1f%%", s);
    }

    // ================= alarm =================

    private void triggerAlarm(String reason) {
        alarmReason = reason;
        state = ALARM;
        if (panel != null) {
            setPanelColor(PANEL_ALARM);
            if (minimized) setMinimized(false);
        }
        setMessage("⚠ " + reason + "\nPress STOP ALARM.");
        updateTitle();
        alarm.start();
        EventLog.add(this, "ALARM: " + reason);
        NotificationManager nm = getSystemService(NotificationManager.class);
        Notification n = new Notification.Builder(this, "alarm")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("⚠ " + reason)
                .setContentText("Tap STOP ALARM")
                .setCategory(Notification.CATEGORY_ALARM)
                .addAction(new Notification.Action.Builder(null, "STOP ALARM", servicePI(ACTION_STOP_ALARM, 11)).build())
                .setOngoing(true)
                .build();
        try {
            nm.notify(ALARM_NOTIF_ID, n);
        } catch (Exception ignored) {
        }
    }

    private void cancelAlarmNotification() {
        try {
            getSystemService(NotificationManager.class).cancel(ALARM_NOTIF_ID);
        } catch (Exception ignored) {
        }
    }

    private void stopAlarm(boolean byUser) {
        boolean wasRinging = alarm.isPlaying() || state == ALARM;
        alarm.stop();
        cancelAlarmNotification();
        if (state != ALARM) return;
        if (panel != null) setPanelColor(PANEL_BG);
        if (projection == null) {
            state = ENDED;
            setMessage("Watching has stopped. Press EXIT, then open Aerator Watch and start again.");
            updateTitle();
            return;
        }
        state = WATCH;
        if (byUser) {
            // Silence for one waiting period; rings again if still not fixed.
            snoozeUntil = System.currentTimeMillis() + stillSeconds * 1000L;
            if (wasRinging) EventLog.add(this, "Alarm stopped by you");
        }
        updateTitle();
    }

    private void onProjectionStopped() {
        projection = null;
        if (cleaned) return;
        if (state == WATCH || state == CALIB) {
            triggerAlarm("Watching stopped (screen locked or recording ended)");
        } else if (state == SETUP) {
            state = ENDED;
            setMessage("Screen recording ended. Press EXIT and start again from the app.");
            updateTitle();
        }
    }

    // ================= notifications / housekeeping =================

    private PendingIntent servicePI(String action, int req) {
        Intent i = new Intent(this, WatchService.class).setAction(action);
        return PendingIntent.getService(this, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, "watch")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Aerator Watch")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP ALARM", servicePI(ACTION_STOP_ALARM, 12)).build())
                .addAction(new Notification.Action.Builder(null, "EXIT", servicePI(ACTION_EXIT, 13)).build())
                .build();
    }

    private void updateNotification(String text) {
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification(text));
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "aeratorwatch:screen");
            wakeLock.acquire(14 * 60 * 60 * 1000L);
        } catch (Exception ignored) {
        }
    }

    private void cleanup() {
        if (cleaned) return;
        boolean wasWatching = state == WATCH || state == ALARM || state == CALIB;
        cleaned = true;
        state = ENDED;
        running = false;
        handler.removeCallbacks(tick);
        alarm.stop();
        cancelAlarmNotification();
        if (wasWatching) EventLog.add(this, "Watching ended");
        for (Slot s : slots) {
            try { wm.removeView(s.view); } catch (Exception ignored) { }
        }
        if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) { }
        if (vdisplay != null) try { vdisplay.release(); } catch (Exception ignored) { }
        if (projection != null) try { projection.stop(); } catch (Exception ignored) { }
        projection = null;
        if (reader != null) try { reader.close(); } catch (Exception ignored) { }
        if (wakeLock != null && wakeLock.isHeld()) try { wakeLock.release(); } catch (Exception ignored) { }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }
}
