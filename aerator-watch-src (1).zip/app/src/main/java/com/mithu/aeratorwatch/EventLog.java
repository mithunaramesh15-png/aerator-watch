package com.mithu.aeratorwatch;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** A simple history of what happened during the night (newest first). */
public class EventLog {
    private static final int MAX_LINES = 200;

    static synchronized void add(Context c, String msg) {
        SharedPreferences p = c.getSharedPreferences(WatchService.PREFS, Context.MODE_PRIVATE);
        String time = new SimpleDateFormat("dd MMM  hh:mm a", Locale.US).format(new Date());
        String old = p.getString("log", "");
        String all = time + "   " + msg + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        if (lines.length > MAX_LINES) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < MAX_LINES; i++) {
                if (i > 0) sb.append('\n');
                sb.append(lines[i]);
            }
            all = sb.toString();
        }
        p.edit().putString("log", all).apply();
    }

    static String get(Context c) {
        return c.getSharedPreferences(WatchService.PREFS, Context.MODE_PRIVATE).getString("log", "");
    }

    static void clear(Context c) {
        c.getSharedPreferences(WatchService.PREFS, Context.MODE_PRIVATE).edit().remove("log").apply();
    }
}
