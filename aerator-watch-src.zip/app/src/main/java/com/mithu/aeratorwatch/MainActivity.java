package com.mithu.aeratorwatch;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 100;
    private SharedPreferences prefs;
    private Button overlayBtn, notifBtn, batteryBtn;
    private TextView secondsText;
    private AlarmPlayer testAlarm;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(WatchService.PREFS, MODE_PRIVATE);
        testAlarm = new AlarmPlayer(this);

        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("Aerator Watch");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        root.addView(text("Watches the two aerator splashes in the EseeCloud live view and rings a loud alarm if one stops.\n\nDo steps 1 to 3 once. Then press START WATCHING each night."));

        overlayBtn = button("1. Allow \"Display over other apps\"");
        overlayBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        root.addView(overlayBtn);

        notifBtn = button("2. Allow notifications");
        notifBtn.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        });
        root.addView(notifBtn);

        batteryBtn = button("3. Let it run all night (battery)");
        batteryBtn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
        root.addView(batteryBtn);

        root.addView(text("\nRing the alarm when a splash is missing for:"));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = button("  −  ");
        Button plus = button("  +  ");
        secondsText = new TextView(this);
        secondsText.setTextSize(20);
        secondsText.setGravity(Gravity.CENTER);
        row.addView(minus);
        row.addView(secondsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(plus);
        root.addView(row);
        minus.setOnClickListener(v -> changeSeconds(-15));
        plus.setOnClickListener(v -> changeSeconds(15));
        changeSeconds(0);

        Button test = button("Test alarm sound (5 seconds)");
        test.setOnClickListener(v -> {
            testAlarm.start();
            handler.postDelayed(testAlarm::stop, 5000);
        });
        root.addView(test);

        Button start = button("▶  START WATCHING");
        start.setTextSize(20);
        start.setBackgroundColor(Color.rgb(0, 140, 70));
        start.setTextColor(Color.WHITE);
        start.setOnClickListener(v -> askToCapture());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.topMargin = dp(16);
        root.addView(start, lp);

        Button stop = button("Stop watching");
        stop.setOnClickListener(v -> {
            startService(new Intent(this, WatchService.class).setAction(WatchService.ACTION_EXIT));
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop);

        root.addView(text("\nTips:\n• Keep the phone plugged in and upright (portrait).\n"
                + "• When Android asks, choose \"Entire screen\" (not a single app).\n"
                + "• Keep the EseeCloud live view open on the screen. Do not lock the phone. "
                + "You can turn the brightness down.\n"
                + "• Turn up the alarm volume and test it before sleeping."));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean overlay = Settings.canDrawOverlays(this);
        overlayBtn.setText((overlay ? "✓ " : "") + "1. Allow \"Display over other apps\"");
        boolean notif = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        notifBtn.setText((notif ? "✓ " : "") + "2. Allow notifications");
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        boolean batt = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryBtn.setText((batt ? "✓ " : "") + "3. Let it run all night (battery)");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        onResume();
    }

    private void changeSeconds(int delta) {
        int s = prefs.getInt("still", 45) + delta;
        s = Math.max(15, Math.min(600, s));
        prefs.edit().putInt("still", s).apply();
        secondsText.setText(s + " seconds");
    }

    private void askToCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please do step 1 first", Toast.LENGTH_LONG).show();
            return;
        }
        if (WatchService.running) {
            Toast.makeText(this, "Already watching. Press Stop watching first.", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent i;
        if (Build.VERSION.SDK_INT >= 34) {
            i = mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            i = mpm.createScreenCaptureIntent();
        }
        startActivityForResult(i, REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Screen permission was not given", Toast.LENGTH_LONG).show();
            return;
        }
        Intent s = new Intent(this, WatchService.class)
                .setAction(WatchService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data);
        startForegroundService(s);
        Toast.makeText(this, "Now open EseeCloud live view and place the boxes", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(15);
        t.setPadding(0, dp(8), 0, dp(8));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
