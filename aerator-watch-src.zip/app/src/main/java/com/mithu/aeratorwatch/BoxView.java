package com.mithu.aeratorwatch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** A see-through rectangle drawn over the camera video, marking one aerator. */
public class BoxView extends View {
    private final String label;
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private String info = "";
    private boolean editable = true;

    public BoxView(Context c, String label) {
        super(c);
        this.label = label;
        dp = c.getResources().getDisplayMetrics().density;
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(3 * dp);
        border.setColor(Color.CYAN);
        handle.setStyle(Paint.Style.FILL);
        handle.setColor(Color.CYAN);
        text.setColor(Color.WHITE);
        text.setTextSize(12 * dp);
        text.setFakeBoldText(true);
        text.setShadowLayer(3 * dp, 0, 0, Color.BLACK);
    }

    public void setState(int color, String info, boolean editable) {
        border.setColor(color);
        handle.setColor(color);
        this.info = info;
        this.editable = editable;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float s = border.getStrokeWidth() / 2f;
        c.drawRect(s, s, w - s, h - s, border);
        c.drawText(label + "  " + info, 6 * dp, 15 * dp, text);
        if (editable) {
            float k = 28 * dp;
            Path p = new Path();
            p.moveTo(w, h - k);
            p.lineTo(w, h);
            p.lineTo(w - k, h);
            p.close();
            c.drawPath(p, handle);
        }
    }
}
