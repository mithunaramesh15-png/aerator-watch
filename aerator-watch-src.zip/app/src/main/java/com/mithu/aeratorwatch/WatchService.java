package com.mithu.aeratorwatch;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Locale;

/**
 * Watches the screen (the EseeCloud live view) inside two boxes.
 * Each box should sit on one aerator's white splash. If the picture inside
 * a box stops changing for too long, a loud alarm rings.
 */
public class WatchService extends Service {
    static final String ACTION_START = "com.mithu.aeratorwatch.START";
    static final String ACTION_STOP_ALARM = "com.mithu.aeratorwatch.STOP_ALARM";
    static final String ACTION_EXIT = "com.mithu.aeratorwatch.EXIT";
    static final String PREFS = "aerator";
    static volatile boolean running = false;

    private static final int NOTIF_ID = 1;
    private static final int ALARM_NOTIF_ID = 2;
    private static final int CALIB_TICKS = 15;
    private static final int PIXEL_DIFF = 14;

    private static final int SETUP = 0, CALIB = 1, WATCH = 2, ALARM = 3, ENDED = 4;

    private WindowManager wm;
    private Handler handler;
    private SharedPreferences prefs;
    private AlarmPlayer alarm;
    private PowerManager.WakeLock wakeLock;

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;
    private int screenW, screenH, capW, capH;

    private final BoxView[] boxes = new BoxView[2];
    private final WindowManager.LayoutParams[] boxParams = new WindowManager.LayoutParams[2];
    private LinearLayout panel;
    private WindowManager.LayoutParams panelParams;
    private TextView status;
    private Button startBtn;

    private int state = SETUP;
    private boolean cleaned = false;
    private final int[][] prev = new int[2][];
    private final float[] threshold = new float[2];
    private final float[][] calib = new float[2][CALIB_TICKS];
    private final int[] calibCount = new int[2];
    private int calibTick = 0;
    private int stillSeconds = 45;
    private boolean[][] history;
    private int histPos = 0, histCount = 0;
    private final int[] stillRun = new int[2];
    private final float[] lastScore = new float[2];
    private String alarmReason = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        handler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        alarm = new AlarmPlayer(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("watch", "Watching", NotificationManager.IMPORTANCE_LOW));
        NotificationChannel ch = new NotificationChannel("alarm", "Aerator alarm", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String a = intent.getAction();
        if (ACTION_START.equals(a)) {
            if (projection != null) return START_NOT_STICKY;
            Notification n = buildNotification("Place the boxes on the aerators, then press START.", false);
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIF_ID, n);
            }
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            try {
                projection = mpm.getMediaProjection(code, data);
            } catch (Exception e) {
                projection = null;
            }
            if (projection == null) {
                cleanup();
                return START_NOT_STICKY;
            }
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    handler.post(WatchService.this::onProjectionStopped);
                }
            }, handler);
            setupCapture();
            showOverlays();
            acquireWakeLock();
            running = true;
            handler.post(tick);
        } else if (ACTION_STOP_ALARM.equals(a)) {
            stopAlarm();
        } else if (ACTION_EXIT.equals(a)) {
            cleanup();
        }
        return START_NOT_STICKY;
    }

    // ---------- screen capture ----------

    private void setupCapture() {
        if (Build.VERSION.SDK_INT >= 30) {
            screenW = wm.getMaximumWindowMetrics().getBounds().width();
            screenH = wm.getMaximumWindowMetrics().getBounds().height();
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        }
        capW = Math.max(2, (screenW / 2) & ~1);
        capH = Math.max(2, (screenH / 2) & ~1);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        vdisplay = projection.createVirtualDisplay("aerator-watch", capW, capH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
    }

    // ---------- overlays ----------

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private WindowManager.LayoutParams overlayParams(int w, int h, int extraFlags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | extraFlags,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return p;
    }

    private void showOverlays() {
        int defW = (int) (screenW * 0.40f), defH = (int) (screenH * 0.10f);
        int[] defY = {(int) (screenH * 0.22f), (int) (screenH * 0.50f)};
        for (int i = 0; i < 2; i++) {
            boxes[i] = new BoxView(this, "Aerator " + (i + 1));
            WindowManager.LayoutParams p = overlayParams(
                    prefs.getInt("w" + i, defW), prefs.getInt("h" + i, defH),
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            p.gravity = Gravity.TOP | Gravity.LEFT;
            p.x = prefs.getInt("x" + i, (int) (screenW * 0.30f));
            p.y = prefs.getInt("y" + i, defY[i]);
            boxParams[i] = p;
            boxes[i].setOnTouchListener(new BoxTouch(i));
            boxes[i].setState(Color.CYAN, "", true);
            wm.addView(boxes[i], p);
        }

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(10);
        panel.setPadding(pad, pad, pad, pad);
        setPanelColor(0xDD202833);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        panel.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        startBtn = makeButton("START");
        Button stopBtn = makeButton("STOP ALARM");
        Button exitBtn = makeButton("EXIT");
        row.addView(startBtn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(stopBtn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f));
        row.addView(exitBtn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f));
        panel.addView(row);

        startBtn.setOnClickListener(v -> {
            if (state == SETUP) beginWatching();
            else backToSetup();
        });
        stopBtn.setOnClickListener(v -> stopAlarm());
        exitBtn.setOnClickListener(v -> cleanup());

        // Drag the text part of the panel up or down to move it.
        status.setOnTouchListener(new View.OnTouchListener() {
            float downY;
            int startY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    downY = e.getRawY();
                    startY = panelParams.y;
                } else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    panelParams.y = Math.max(0, startY - (int) (e.getRawY() - downY));
                    safeUpdate(panel, panelParams);
                }
                return true;
            }
        });

        panelParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        panelParams.gravity = Gravity.BOTTOM;
        panelParams.y = dp(40);
        wm.addView(panel, panelParams);
        setStatus("Open EseeCloud live view. Drag each box onto its aerator splash "
                + "(drag the corner to resize). Then press START.");
    }

    private Button makeButton(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(13);
        return b;
    }

    private void setPanelColor(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        panel.setBackground(bg);
    }

    private void setStatus(String s) {
        if (status != null) status.setText(s);
    }

    private void safeUpdate(View v, WindowManager.LayoutParams p) {
        try {
            wm.updateViewLayout(v, p);
        } catch (Exception ignored) {
        }
    }

    private class BoxTouch implements View.OnTouchListener {
        private final int i;
        private float downX, downY;
        private int sx, sy, sw, sh;
        private boolean resizing;

        BoxTouch(int i) {
            this.i = i;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            if (state != SETUP) return false;
            WindowManager.LayoutParams p = boxParams[i];
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    sx = p.x;
                    sy = p.y;
                    sw = v.getWidth();
                    sh = v.getHeight();
                    int corner = dp(48);
                    resizing = e.getX() > sw - corner && e.getY() > sh - corner;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (e.getRawX() - downX), dy = (int) (e.getRawY() - downY);
                    if (resizing) {
                        p.width = Math.max(dp(60), sw + dx);
                        p.height = Math.max(dp(50), sh + dy);
                    } else {
                        p.x = sx + dx;
                        p.y = sy + dy;
                    }
                    safeUpdate(v, p);
                    prev[i] = null;
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    prefs.edit()
                            .putInt("x" + i, p.x).putInt("y" + i, p.y)
                            .putInt("w" + i, v.getWidth()).putInt("h" + i, v.getHeight())
                            .apply();
                    return true;
            }
            return false;
        }
    }

    private void setBoxesTouchable(boolean touchable) {
        for (int i = 0; i < 2; i++) {
            if (boxes[i] == null) continue;
            if (touchable) boxParams[i].flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            else boxParams[i].flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            safeUpdate(boxes[i], boxParams[i]);
        }
    }

    // ---------- watching logic ----------

    private void beginWatching() {
        stillSeconds = prefs.getInt("still", 45);
        history = new boolean[2][stillSeconds];
        histPos = 0;
        histCount = 0;
        calibTick = 0;
        calibCount[0] = calibCount[1] = 0;
        stillRun[0] = stillRun[1] = 0;
        state = CALIB;
        setBoxesTouchable(false);
        startBtn.setText("EDIT BOXES");
        updateNotification("Watching the aerators.", false);
    }

    private void backToSetup() {
        alarm.stop();
        cancelAlarmNotification();
        if (projection == null) return;
        state = SETUP;
        setPanelColor(0xDD202833);
        setBoxesTouchable(true);
        startBtn.setText("START");
    }

    private void resetHistory() {
        histPos = 0;
        histCount = 0;
        stillRun[0] = stillRun[1] = 0;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (state == ENDED || cleaned) return;
            try {
                doTick();
            } catch (Exception ignored) {
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void doTick() {
        float[] score = {0f, 0f};
        Image img = null;
        try {
            img = reader.acquireLatestImage();
        } catch (Exception ignored) {
        }
        if (img != null) {
            try {
                Image.Plane pl = img.getPlanes()[0];
                ByteBuffer buf = pl.getBuffer();
                for (int i = 0; i < 2; i++) {
                    score[i] = measure(i, buf, pl.getPixelStride(), pl.getRowStride());
                }
            } finally {
                img.close();
            }
        }
        // No new frame at all means nothing on screen changed: counts as "still" (score 0).
        lastScore[0] = score[0];
        lastScore[1] = score[1];

        switch (state) {
            case SETUP:
                for (int i = 0; i < 2; i++) {
                    boxes[i].setState(Color.CYAN, fmt(score[i]), true);
                }
                break;
            case CALIB:
                for (int i = 0; i < 2; i++) {
                    if (score[i] > 0) calib[i][calibCount[i]++] = score[i];
                    boxes[i].setState(Color.YELLOW, fmt(score[i]), false);
                }
                calibTick++;
                setStatus("Learning how the splash looks... keep both aerators running ("
                        + (CALIB_TICKS - calibTick) + " s)");
                if (calibTick >= CALIB_TICKS) finishCalibration();
                break;
            case WATCH:
            case ALARM:
                watchStep(score);
                break;
        }
    }

    private void finishCalibration() {
        StringBuilder warn = new StringBuilder();
        for (int i = 0; i < 2; i++) {
            float median = 0f;
            if (calibCount[i] > 0) {
                float[] s = Arrays.copyOf(calib[i], calibCount[i]);
                Arrays.sort(s);
                median = s[s.length / 2];
            }
            threshold[i] = Math.max(median * 0.3f, 0.5f);
            if (median < 1.5f) {
                warn.append("\nAerator ").append(i + 1)
                        .append(": very little movement seen. Is the box on the splash?");
            }
        }
        state = WATCH;
        resetHistory();
        setStatus("Watching. Alarm if a splash stops for " + stillSeconds + " s." + warn);
    }

    private void watchStep(float[] score) {
        for (int i = 0; i < 2; i++) {
            boolean moving = score[i] < 0 || score[i] >= threshold[i];
            history[i][histPos] = moving;
            stillRun[i] = moving ? 0 : stillRun[i] + 1;
        }
        histPos = (histPos + 1) % stillSeconds;
        if (histCount < stillSeconds) histCount++;

        StringBuilder sb = new StringBuilder();
        String stopped = null;
        for (int i = 0; i < 2; i++) {
            int movingCount = 0;
            for (boolean b : history[i]) if (b) movingCount++;
            // Full window seen and almost no movement in it -> stopped.
            boolean isStopped = histCount >= stillSeconds && movingCount <= stillSeconds * 0.15f;
            if (isStopped && stopped == null) stopped = "Aerator " + (i + 1) + " STOPPED!";
            int color = isStopped ? Color.RED : (stillRun[i] > 3 ? Color.rgb(255, 165, 0) : Color.GREEN);
            String txt = fmt(score[i]) + (stillRun[i] > 3 ? "  still " + stillRun[i] + "s" : "");
            boxes[i].setState(color, txt, false);
            sb.append("Aerator ").append(i + 1).append(": ")
                    .append(isStopped ? "STOPPED" : (stillRun[i] > 3 ? "still " + stillRun[i] + " s" : "running"))
                    .append(i == 0 ? "   |   " : "");
        }
        if (state == ALARM) {
            setStatus("⚠ " + alarmReason + "\nPress STOP ALARM. (" + sb + ")");
        } else {
            setStatus("Watching (alarm after " + stillSeconds + " s).\n" + sb);
            if (stopped != null) triggerAlarm(stopped);
        }
    }

    /** Percentage of sample points inside the box that changed since the last check. */
    private float measure(int i, ByteBuffer buf, int ps, int rs) {
        BoxView v = boxes[i];
        int w = v.getWidth(), h = v.getHeight();
        if (w == 0 || h == 0) return -1;
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        float sx = capW / (float) screenW, sy = capH / (float) screenH;
        int side = dp(6), top = dp(22);
        int x0 = clamp((int) ((loc[0] + side) * sx), 0, capW - 1);
        int x1 = clamp((int) ((loc[0] + w - side) * sx), 0, capW - 1);
        int y0 = clamp((int) ((loc[1] + top) * sy), 0, capH - 1);
        int y1 = clamp((int) ((loc[1] + h - side) * sy), 0, capH - 1);
        if (x1 - x0 < 4 || y1 - y0 < 4) return -1;
        int step = Math.max(1, Math.max(x1 - x0, y1 - y0) / 80);
        int nx = (x1 - x0) / step, ny = (y1 - y0) / step;
        int n = nx * ny;
        if (n <= 0) return -1;
        int[] cur = new int[n];
        int k = 0;
        int limit = buf.limit();
        for (int yy = 0; yy < ny; yy++) {
            int py = y0 + yy * step;
            for (int xx = 0; xx < nx; xx++) {
                int off = py * rs + (x0 + xx * step) * ps;
                if (off + 2 >= limit) {
                    cur[k++] = 0;
                    continue;
                }
                int r = buf.get(off) & 0xff, g = buf.get(off + 1) & 0xff, b = buf.get(off + 2) & 0xff;
                cur[k++] = (r + 2 * g + b) >> 2;
            }
        }
        int[] p = prev[i];
        prev[i] = cur;
        if (p == null || p.length != n) return -1;
        int changed = 0;
        for (int j = 0; j < n; j++) if (Math.abs(cur[j] - p[j]) > PIXEL_DIFF) changed++;
        return 100f * changed / n;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static String fmt(float s) {
        if (s < 0) return "...";
        return String.format(Locale.US, "%.1f%%", s);
    }

    // ---------- alarm ----------

    private void triggerAlarm(String reason) {
        alarmReason = reason;
        state = ALARM;
        if (panel != null) setPanelColor(0xEEB00020);
        setStatus("⚠ " + reason + "\nPress STOP ALARM.");
        alarm.start();
        NotificationManager nm = getSystemService(NotificationManager.class);
        Notification n = new Notification.Builder(this, "alarm")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("⚠ " + reason)
                .setContentText("Tap STOP ALARM")
                .setCategory(Notification.CATEGORY_ALARM)
                .addAction(new Notification.Action.Builder(null, "STOP ALARM", servicePI(ACTION_STOP_ALARM, 11)).build())
                .setOngoing(true)
                .build();
        try {
            nm.notify(ALARM_NOTIF_ID, n);
        } catch (Exception ignored) {
        }
    }

    private void cancelAlarmNotification() {
        try {
            getSystemService(NotificationManager.class).cancel(ALARM_NOTIF_ID);
        } catch (Exception ignored) {
        }
    }

    private void stopAlarm() {
        alarm.stop();
        cancelAlarmNotification();
        if (state != ALARM) return;
        if (panel != null) setPanelColor(0xDD202833);
        if (projection == null) {
            state = ENDED;
            setStatus("Watching has stopped. Press EXIT, then open Aerator Watch and start again.");
        } else {
            // Keep watching: if the splash is still missing, it rings again after the wait time.
            state = WATCH;
            resetHistory();
            setStatus("Alarm stopped. Still watching.");
        }
    }

    private void onProjectionStopped() {
        projection = null;
        if (cleaned) return;
        if (state == WATCH || state == CALIB) {
            triggerAlarm("Watching stopped (screen locked or recording ended)");
        } else if (state == SETUP) {
            state = ENDED;
            setStatus("Screen recording ended. Press EXIT and start again from the app.");
        }
    }

    // ---------- notifications / housekeeping ----------

    private PendingIntent servicePI(String action, int req) {
        Intent i = new Intent(this, WatchService.class).setAction(action);
        return PendingIntent.getService(this, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification(String text, boolean alarmOn) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, "watch")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Aerator Watch")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP ALARM", servicePI(ACTION_STOP_ALARM, 12)).build())
                .addAction(new Notification.Action.Builder(null, "EXIT", servicePI(ACTION_EXIT, 13)).build())
                .build();
    }

    private void updateNotification(String text, boolean alarmOn) {
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification(text, alarmOn));
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "aeratorwatch:screen");
            wakeLock.acquire(14 * 60 * 60 * 1000L);
        } catch (Exception ignored) {
        }
    }

    private void cleanup() {
        if (cleaned) return;
        cleaned = true;
        state = ENDED;
        running = false;
        handler.removeCallbacks(tick);
        alarm.stop();
        cancelAlarmNotification();
        for (BoxView b : boxes) {
            if (b != null) try { wm.removeView(b); } catch (Exception ignored) { }
        }
        if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) { }
        if (vdisplay != null) try { vdisplay.release(); } catch (Exception ignored) { }
        if (projection != null) try { projection.stop(); } catch (Exception ignored) { }
        projection = null;
        if (reader != null) try { reader.close(); } catch (Exception ignored) { }
        if (wakeLock != null && wakeLock.isHeld()) try { wakeLock.release(); } catch (Exception ignored) { }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }
}
